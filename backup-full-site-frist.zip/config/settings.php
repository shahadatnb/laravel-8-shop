<?php
if(class_exists(\CustomHelper::class)){
    return \CustomHelper::settingAll();
}

