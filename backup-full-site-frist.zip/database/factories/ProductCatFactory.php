<?php

namespace Database\Factories;

use App\Models\ProductCat;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductCatFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ProductCat::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
