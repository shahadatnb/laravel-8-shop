<?php return array (
  'checkout-cart' => 'App\\Http\\Livewire\\CheckoutCart',
  'checkout-checkout' => 'App\\Http\\Livewire\\CheckoutCheckout',
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'mini-cart' => 'App\\Http\\Livewire\\MiniCart',
  'product.create' => 'App\\Http\\Livewire\\Product\\Create',
  'product.images' => 'App\\Http\\Livewire\\Product\\Images',
  'product.product' => 'App\\Http\\Livewire\\Product\\Product',
  'product.single-product' => 'App\\Http\\Livewire\\Product\\SingleProduct',
  'product.variant' => 'App\\Http\\Livewire\\Product\\Variant',
  'shop' => 'App\\Http\\Livewire\\Shop',
  'subscribe-form' => 'App\\Http\\Livewire\\SubscribeForm',
);